@echo off
setlocal EnableDelayedExpansion

set "PASSWORD=ANNA_NAMIK_SECRET_KEYSTORE"
set "DOMAIN=localhost"
set "COMPANY=MyCompany"

echo ===============================================
echo  Generating Complete Certificate Chain
echo ===============================================

echo [1/8] Generating Root CA...
openssl genrsa -aes256 -out rootCA.key -passout pass:!PASSWORD! 4096
openssl req -x509 -new -nodes -key rootCA.key -sha256 -days 3650 -out rootCA.crt -subj "/C=RU/ST=Moscow/L=Moscow/O=!COMPANY!/CN=!COMPANY! Root CA" -passin pass:!PASSWORD!
keytool -import -trustcacerts -alias rootCA -file rootCA.crt -keystore rootCA.jks -storepass !PASSWORD! -noprompt

echo [2/8] Generating Intermediate CA...
openssl genrsa -out intermediateCA.key 4096
openssl req -new -key intermediateCA.key -out intermediateCA.csr -subj "/C=RU/ST=Moscow/L=Moscow/O=!COMPANY!/CN=!COMPANY! Intermediate CA"
openssl x509 -req -in intermediateCA.csr -CA rootCA.crt -CAkey rootCA.key -CAcreateserial -out intermediateCA.crt -days 1825 -sha256 -passin pass:!PASSWORD!
keytool -import -trustcacerts -alias intermediateCA -file intermediateCA.crt -keystore intermediateCA.jks -storepass !PASSWORD! -noprompt

echo [3/8] Generating Server Certificate...
openssl genrsa -out server.key 4096
openssl req -new -key server.key -out server.csr -subj "/C=RU/ST=Moscow/L=Moscow/O=!COMPANY!/CN=!DOMAIN!"
openssl x509 -req -in server.csr -CA intermediateCA.crt -CAkey intermediateCA.key -CAcreateserial -out server.crt -days 365 -sha256

echo [4/8] Creating certificate chain file...
type server.crt > server-chain.crt
type intermediateCA.crt >> server-chain.crt
type rootCA.crt >> server-chain.crt

echo [5/8] Creating PKCS12 keystores...
openssl pkcs12 -export -in server.crt -inkey server.key -out keystore.p12 -name server -certfile server-chain.crt -password pass:!PASSWORD!
openssl pkcs12 -export -in server.crt -inkey server.key -out server.p12 -name server -certfile server-chain.crt -password pass:!PASSWORD!

echo [6/8] Creating JKS keystores...
keytool -importkeystore -srckeystore keystore.p12 -srcstoretype PKCS12 -destkeystore server.jks -deststoretype JKS -srcstorepass !PASSWORD! -deststorepass !PASSWORD! -noprompt

echo [7/8] Creating truststore...
keytool -import -trustcacerts -alias rootCA -file rootCA.crt -keystore truststore.jks -storepass !PASSWORD! -noprompt
keytool -import -trustcacerts -alias intermediateCA -file intermediateCA.crt -keystore truststore.jks -storepass !PASSWORD! -noprompt

echo [8/8] Verifying certificates...
keytool -list -v -keystore keystore.p12 -storepass !PASSWORD! | findstr "Alias"
openssl verify -CAfile rootCA.crt -untrusted intermediateCA.crt server.crt

echo ===============================================
echo  CERTIFICATION GENERATION COMPLETE!
echo ===============================================
echo Files created:
echo   - rootCA.key, rootCA.crt, rootCA.jks
echo   - intermediateCA.key, intermediateCA.crt, intermediateCA.csr, intermediateCA.jks
echo   - server.key, server.crt, server.csr, server.jks, server.p12
echo   - keystore.p12 (main file for Spring Boot)
echo   - truststore.jks
echo   - server-chain.crt
echo.
echo For Spring Boot, use: keystore.p12
echo Password: !PASSWORD!
echo ===============================================

pause