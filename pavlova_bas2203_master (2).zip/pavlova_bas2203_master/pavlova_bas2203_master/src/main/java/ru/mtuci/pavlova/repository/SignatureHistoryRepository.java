package ru.mtuci.pavlova.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.mtuci.pavlova.model.SignatureHistory;

public interface SignatureHistoryRepository extends JpaRepository<SignatureHistory, Long> {
}