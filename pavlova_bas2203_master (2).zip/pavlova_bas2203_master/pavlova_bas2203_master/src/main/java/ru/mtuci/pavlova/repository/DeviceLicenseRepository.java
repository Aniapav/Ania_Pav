package ru.mtuci.pavlova.repository;

import ru.mtuci.pavlova.model.Device;
import ru.mtuci.pavlova.model.DeviceLicense;
import ru.mtuci.pavlova.model.License;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DeviceLicenseRepository extends JpaRepository<DeviceLicense, Long> {
    Optional<DeviceLicense> findByDeviceAndLicense(Device device, License license);
}
