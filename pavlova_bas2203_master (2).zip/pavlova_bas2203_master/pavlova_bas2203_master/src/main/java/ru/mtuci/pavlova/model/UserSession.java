package ru.mtuci.pavlova.model;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;


@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "user_sessions")
public class UserSession {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false, length = 1024)
    private String deviceId;

    @Column(nullable = false, length = 1024)
    private String accessToken;

    @Column(nullable = false, length = 1024)
    private String refreshToken;

    @Column(nullable = false)
    private Date accessTokenExpiration;

    @Column(nullable = false)
    private Date refreshTokenExpiration;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SessionStatus status;

    @Version
    private Long version;
}
