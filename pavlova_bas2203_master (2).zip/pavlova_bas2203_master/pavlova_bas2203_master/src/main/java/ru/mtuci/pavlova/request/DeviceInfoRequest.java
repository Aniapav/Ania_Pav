package ru.mtuci.pavlova.request;

import lombok.Data;

@Data
public class DeviceInfoRequest {
    private String name, macAddress;
}
