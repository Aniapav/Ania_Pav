package ru.mtuci.pavlova.service;

public interface SignatureVerificationService {
    void verifySignatures();

}
