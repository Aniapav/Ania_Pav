package ru.mtuci.pavlova.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.mtuci.pavlova.model.SignatureEntity;
import ru.mtuci.pavlova.service.SignatureService;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;

@Service
@RequiredArgsConstructor
public class SignatureServiceImpl implements SignatureService {

    private final KeyPair keyPair;

    @Override
    public byte[] sign(byte[] data) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(keyPair.getPrivate());
        signature.update(data);
        return signature.sign();
    }

    @Override
    public boolean verify(byte[] data, byte[] signatureBytes) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(keyPair.getPublic());
        signature.update(data);
        return signature.verify(signatureBytes);
    }

    @Override
    public byte[] getDataToSign(SignatureEntity entity) {
        String data = entity.getId().toString()
                + entity.getThreatName()
                + new String(entity.getFirstBytes(), StandardCharsets.UTF_8)
                + entity.getRemainderHash()
                + entity.getRemainderLength()
                + entity.getFileType()
                + entity.getOffsetStart()
                + entity.getOffsetEnd()
                + entity.getUpdatedAt().toString()
                + entity.getStatus().name();
        return data.getBytes(StandardCharsets.UTF_8);
    }
}
