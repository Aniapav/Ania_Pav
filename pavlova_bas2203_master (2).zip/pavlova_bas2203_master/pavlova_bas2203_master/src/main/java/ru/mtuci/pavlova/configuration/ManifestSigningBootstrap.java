package ru.mtuci.pavlova.configuration;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Date;

/**
 * Loads a persistent PKCS#12 signing keystore or creates one (RSA-2048, SHA256withRSA self-signed cert).
 */
public final class ManifestSigningBootstrap {

    private static final Logger log = LoggerFactory.getLogger(ManifestSigningBootstrap.class);

    private static volatile X509Certificate signingCertificate;

    private ManifestSigningBootstrap() {
    }

    public static X509Certificate getSigningCertificate() {
        X509Certificate c = signingCertificate;
        if (c == null) {
            throw new IllegalStateException("Manifest signing certificate is not initialised yet");
        }
        return c;
    }

    public static KeyPair loadOrCreate(ManifestSigningProperties props) throws Exception {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }

        Path keystorePath = Path.of(props.getKeystoreFile()).toAbsolutePath().normalize();
        char[] password = props.getKeystorePassword().toCharArray();
        String alias = props.getAlias();
        Path certExportPath = Path.of(props.getPublicCertExport()).toAbsolutePath().normalize();

        if (Files.exists(keystorePath)) {
            KeyStore store = KeyStore.getInstance("PKCS12");
            try (InputStream in = Files.newInputStream(keystorePath)) {
                store.load(in, password);
            }
            PrivateKey privateKey = (PrivateKey) store.getKey(alias, password);
            Certificate cert = store.getCertificate(alias);
            if (!(cert instanceof X509Certificate x509)) {
                throw new IllegalStateException("Certificate for alias " + alias + " is not X.509");
            }
            signingCertificate = x509;
            log.info("Loaded manifest signing keystore from {}", keystorePath);
            return new KeyPair(x509.getPublicKey(), privateKey);
        }

        Files.createDirectories(keystorePath.getParent());
        Files.createDirectories(certExportPath.getParent());

        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME);
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();

        Date notBefore = new Date();
        Date notAfter = new Date(notBefore.getTime() + 20L * 365 * 86400_000L);
        X500Name dn = new X500Name("CN=Antimalware manifest signing,O=MTUCI,C=RU");
        BigInteger serial = BigInteger.valueOf(System.currentTimeMillis());

        JcaX509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
                dn,
                serial,
                notBefore,
                notAfter,
                dn,
                kp.getPublic()
        );

        ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA")
                .setProvider(BouncyCastleProvider.PROVIDER_NAME)
                .build(kp.getPrivate());

        X509CertificateHolder holder = certBuilder.build(signer);
        X509Certificate cert = new JcaX509CertificateConverter()
                .setProvider(BouncyCastleProvider.PROVIDER_NAME)
                .getCertificate(holder);

        KeyStore store = KeyStore.getInstance("PKCS12");
        store.load(null, password);
        store.setKeyEntry(alias, kp.getPrivate(), password, new Certificate[]{cert});

        try (OutputStream os = Files.newOutputStream(keystorePath)) {
            store.store(os, password);
        }

        try (OutputStream os = Files.newOutputStream(certExportPath)) {
            os.write(cert.getEncoded());
        }

        signingCertificate = cert;
        log.warn("Created new manifest signing PKCS#12 at {} (password from configuration). "
                        + "Distribute {} to the Windows Antimalware service for RSA manifest verification.",
                keystorePath, certExportPath);
        return kp;
    }
}
