package ru.mtuci.pavlova.model;


public enum SessionStatus {
    ACTIVE, USED, REVOKED
}