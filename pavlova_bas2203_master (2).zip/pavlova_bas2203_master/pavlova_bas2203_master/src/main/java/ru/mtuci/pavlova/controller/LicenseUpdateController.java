package ru.mtuci.pavlova.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mtuci.pavlova.configuration.JwtTokenProvider;
import ru.mtuci.pavlova.exceptions.categories.AuthenticationErrorException;
import ru.mtuci.pavlova.exceptions.categories.UserNotFoundException;
import ru.mtuci.pavlova.model.ApplicationUser;
import ru.mtuci.pavlova.model.Ticket;
import ru.mtuci.pavlova.request.LicenseUpdateRequest;
import ru.mtuci.pavlova.service.impl.AuthenticationServiceImpl;
import ru.mtuci.pavlova.service.impl.LicenseServiceImpl;
import ru.mtuci.pavlova.service.impl.UserServiceImpl;

import java.util.List;

@RestController
@RequestMapping("/licenseUpdate")
@RequiredArgsConstructor
public class LicenseUpdateController {
    private final JwtTokenProvider jwtTokenProvider;
    private final UserServiceImpl userService;
    private final AuthenticationServiceImpl authenticationService;
    private final LicenseServiceImpl licenseService;

    @PostMapping
    public ResponseEntity<?> licenseUpdate(@RequestHeader("Authorization") String auth, @RequestBody LicenseUpdateRequest licenseUpdateRequest) {
        try {
            // Получить аутентифицированного пользователя
            String login = jwtTokenProvider.getUsername(auth.split(" ")[1]);
            ApplicationUser user = userService.getUserByLogin(login).orElseThrow(
                    () -> new UserNotFoundException("Пользователь не найден")
            );

            // Аунтентификация пользователя
            if (!authenticationService.authenticate(user, licenseUpdateRequest.getPassword()))
                throw new AuthenticationErrorException("Аутентификация не удалась");

            // запрос на продление
            List<Ticket> tickets = licenseService.licenseRenewal(licenseUpdateRequest.getCodeActivation(), user);

            return ResponseEntity.ok(tickets);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(String.format("Ошибка(%s)", e.getMessage()));
        }
    }
}