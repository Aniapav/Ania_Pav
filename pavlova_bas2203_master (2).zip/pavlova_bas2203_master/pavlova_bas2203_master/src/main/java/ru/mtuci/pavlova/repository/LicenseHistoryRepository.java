package ru.mtuci.pavlova.repository;

import ru.mtuci.pavlova.model.LicenseHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LicenseHistoryRepository extends JpaRepository<LicenseHistory, Long> {
}
