package ru.mtuci.pavlova.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.mtuci.pavlova.configuration.ManifestSigningBootstrap;
import ru.mtuci.pavlova.service.LegacyAntivirusBinaryService;

import java.security.cert.CertificateEncodingException;

@RestController
@RequiredArgsConstructor
public class LegacyAntivirusSignatureController {

    private final LegacyAntivirusBinaryService legacyAntivirusBinaryService;

    @GetMapping(value = "/signature/data", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public byte[] legacySignatureData() {
        return legacyAntivirusBinaryService.buildClientBasesBinary();
    }

    @GetMapping(value = "/signature/manifest", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public byte[] legacySignatureManifest() {
        return legacyAntivirusBinaryService.buildManifestForCurrentData();
    }

    /**
     * DER X.509 certificate for the manifest RSA public key (same as {@code manifest-signing-public.cer} on disk).
     */
    @GetMapping(value = "/signature/manifest-public-cert", produces = "application/pkix-cert")
    public byte[] manifestPublicCert() throws CertificateEncodingException {
        return ManifestSigningBootstrap.getSigningCertificate().getEncoded();
    }
}
