package ru.mtuci.pavlova.service;


import ru.mtuci.pavlova.model.ApplicationUser;

public interface AutheneticationService {
    boolean authenticate(ApplicationUser user, String password);
}
