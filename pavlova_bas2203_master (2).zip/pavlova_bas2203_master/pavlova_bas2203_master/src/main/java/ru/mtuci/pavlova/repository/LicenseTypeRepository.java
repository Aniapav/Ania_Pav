package ru.mtuci.pavlova.repository;

import ru.mtuci.pavlova.model.LicenseType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LicenseTypeRepository extends JpaRepository<LicenseType, Long> {
}
