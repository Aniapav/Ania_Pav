package ru.mtuci.pavlova.request;

import lombok.Data;

@Data
public class DeviceRequest {
    private String activationCode, name, macAddress;
}
