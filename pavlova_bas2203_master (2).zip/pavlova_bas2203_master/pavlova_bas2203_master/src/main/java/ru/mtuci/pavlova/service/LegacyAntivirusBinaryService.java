package ru.mtuci.pavlova.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.mtuci.pavlova.model.SignatureEntity;
import ru.mtuci.pavlova.model.SignatureStatus;
import ru.mtuci.pavlova.repository.SignatureRepository;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Builds the legacy binary format consumed by the Windows Antimalware client
 * ({@code AvBasesStore} / {@code StreamReceiver} on the service side).
 */
@Service
@RequiredArgsConstructor
public class LegacyAntivirusBinaryService {

    private final SignatureRepository signatureRepository;
    private final SignatureService signatureService;

    public byte[] buildClientBasesBinary() {
        List<SignatureEntity> list = signatureRepository.findByStatus(SignatureStatus.ACTUAL);
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            writeUInt64Le(baos, list.size());
            for (SignatureEntity e : list) {
                writeUuidAsWindowsLe16(baos, e.getId());
                writeString(baos, e.getThreatName() != null ? e.getThreatName() : "");
                writeUInt64Le(baos, prefixFromFirstBytes(e.getFirstBytes()));
                byte[] hash32 = remainderHashTo32Bytes(e.getRemainderHash());
                baos.write(hash32);
                int remLen = e.getRemainderLength() != null ? e.getRemainderLength() : 0;
                writeUInt32Le(baos, remLen);
                writeString(baos, mapObjectType(e.getFileType()));
                writeUInt64Le(baos, intToU64(e.getOffsetStart()));
                writeUInt64Le(baos, intToU64(e.getOffsetEnd()));
            }
            return baos.toByteArray();
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        }
    }

    public byte[] buildManifestForCurrentData() {
        byte[] data = buildClientBasesBinary();
        return buildManifestBytes(data);
    }

    public byte[] buildManifestBytes(byte[] dataBinary) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(dataBinary);
            long ts = System.currentTimeMillis();
            ByteBuffer payload = ByteBuffer.allocate(40).order(ByteOrder.LITTLE_ENDIAN);
            payload.putLong(ts);
            payload.put(hash);
            byte[] signedPayload = payload.array();
            byte[] rsaSignature = signatureService.sign(signedPayload);

            ByteArrayOutputStream out = new ByteArrayOutputStream(40 + 4 + rsaSignature.length);
            out.write(signedPayload);
            writeUInt32Le(out, rsaSignature.length);
            out.write(rsaSignature);
            return out.toByteArray();
        } catch (NoSuchAlgorithmException | SignatureException | InvalidKeyException e) {
            throw new IllegalStateException(e);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    private static long intToU64(Integer v) {
        if (v == null) {
            return 0L;
        }
        return v & 0xFFFFFFFFL;
    }

    private static void writeUuidAsWindowsLe16(ByteArrayOutputStream baos, UUID uuid) {
        ByteBuffer buf = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt((int) (uuid.getMostSignificantBits() >>> 32));
        buf.putShort((short) ((uuid.getMostSignificantBits() >>> 16) & 0xFFFF));
        buf.putShort((short) (uuid.getMostSignificantBits() & 0xFFFF));
        buf.putLong(uuid.getLeastSignificantBits());
        byte[] arr = buf.array();
        baos.write(arr, 0, arr.length);
    }

    private static long prefixFromFirstBytes(byte[] firstBytes) {
        if (firstBytes == null || firstBytes.length == 0) {
            return 0L;
        }
        byte[] pad = Arrays.copyOf(firstBytes, 8);
        return ByteBuffer.wrap(pad).order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    private static byte[] remainderHashTo32Bytes(String remainderHash) {
        byte[] out = new byte[32];
        if (remainderHash == null || remainderHash.isBlank()) {
            return out;
        }
        String s = remainderHash.trim();
        if (s.length() == 64 && s.matches("[0-9a-fA-F]{64}")) {
            for (int i = 0; i < 32; i++) {
                out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
            }
            return out;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(s.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String mapObjectType(String fileType) {
        if (fileType == null) {
            return "Undefined";
        }
        String ft = fileType.trim();
        if (ft.isEmpty()) {
            return "Undefined";
        }
        String u = ft.toUpperCase();
        if (u.equals("PE") || u.equals("EXE") || u.contains("PORTABLE")) {
            return "PE";
        }
        if (u.contains("PYTHON") || u.endsWith(".PY")) {
            return "PythonScript";
        }
        return "Undefined";
    }

    private static void writeUInt64Le(ByteArrayOutputStream baos, long v) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v);
        baos.write(b.array());
    }

    private static void writeUInt32Le(ByteArrayOutputStream baos, int v) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v);
        baos.write(b.array());
    }

    private static void writeString(ByteArrayOutputStream baos, String s) throws IOException {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        writeUInt64Le(baos, b.length);
        baos.write(b);
    }
}
