package ru.mtuci.pavlova.repository;

import ru.mtuci.pavlova.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}