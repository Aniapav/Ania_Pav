package ru.mtuci.pavlova.service;

import ru.mtuci.pavlova.model.ApplicationUser;
import ru.mtuci.pavlova.model.UserSession;

import java.util.Optional;

public interface TokenService {
    public UserSession issueTokenPair(ApplicationUser user, String deviceId);
    public Optional<UserSession> refreshTokenPair(String refreshToken, String deviceId);
    public void blockAllSessionsForUser(String email);
}
