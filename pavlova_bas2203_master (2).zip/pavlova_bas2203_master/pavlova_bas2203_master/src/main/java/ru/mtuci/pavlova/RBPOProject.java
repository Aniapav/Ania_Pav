package ru.mtuci.pavlova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RBPOProject {

	public static void main(String[] args) {
		SpringApplication.run(RBPOProject.class, args);
	}

}
