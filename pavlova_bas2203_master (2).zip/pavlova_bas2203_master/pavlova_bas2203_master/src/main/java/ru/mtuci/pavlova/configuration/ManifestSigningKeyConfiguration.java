package ru.mtuci.pavlova.configuration;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.security.KeyPair;

@Configuration
@EnableConfigurationProperties(ManifestSigningProperties.class)
public class ManifestSigningKeyConfiguration {

    @Bean
    public KeyPair manifestSigningKeyPair(ManifestSigningProperties properties) throws Exception {
        return ManifestSigningBootstrap.loadOrCreate(properties);
    }
}
