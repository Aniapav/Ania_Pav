package ru.mtuci.pavlova.request;

import lombok.Data;

@Data
public class AuthenticationRequest {
    private String login, password, deviceId;
}
