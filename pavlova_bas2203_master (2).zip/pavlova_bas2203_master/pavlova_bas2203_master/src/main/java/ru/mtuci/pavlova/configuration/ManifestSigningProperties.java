package ru.mtuci.pavlova.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "antivirus.manifest-signing")
public class ManifestSigningProperties {

    /**
     * PKCS#12 file holding the RSA key pair used for entity signatures and manifest signing.
     */
    private String keystoreFile = "data/manifest-signing.p12";

    private String keystorePassword = "changeit";

    private String alias = "manifest";

    /**
     * DER X.509 certificate (public) written next to the keystore for operators / Windows client.
     */
    private String publicCertExport = "data/manifest-signing-public.cer";
}
