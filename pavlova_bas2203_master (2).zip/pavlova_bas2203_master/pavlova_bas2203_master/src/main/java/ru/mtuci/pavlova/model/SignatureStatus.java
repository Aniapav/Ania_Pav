package ru.mtuci.pavlova.model;

public enum SignatureStatus {
    ACTUAL, DELETED, CORRUPTED
}